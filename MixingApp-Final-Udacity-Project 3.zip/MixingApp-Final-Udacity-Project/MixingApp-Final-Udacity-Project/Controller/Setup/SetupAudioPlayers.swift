//
//  SetupAudioPlayers.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import AVFoundation

extension TracksViewController {
    
    func setupAudioPlayers(audioPlayer: AVAudioPlayerNode, indexPath: IndexPath) {
        DispatchQueue.global(qos: .background).async {
            
            let equalizer = AVAudioUnitEQ(numberOfBands: 4)
            
            self.setupEQ(equalizer: equalizer)
            
            self.audioPlayers.remove(at: indexPath.row)
            self.audioPlayers.insert(audioPlayer, at: indexPath.row)
            print("COUNT: \(self.audioPlayers.count)")
            self.equalizers.append(equalizer)
            
            self.audioEngine.attach(audioPlayer)
            self.audioEngine.attach(equalizer)
            
            self.audioEngine.connect(audioPlayer, to: equalizer, format: nil)
            self.audioEngine.connect(equalizer, to: self.mixer, format: nil)
            
        }
    }
    
}
